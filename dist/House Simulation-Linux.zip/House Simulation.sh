#!/bin/sh
java  -jar House Simulation.jar
        